# Installer PC Optimizer v6

1. Extraire l'archive.
2. Vérifier que le SDK .NET est disponible avec `dotnet --version`.
3. Dans `PCOptimizer.App`, tester avec `dotnet build`.
4. Installer Inno Setup 6 ou 7.
5. Lancer `Build-Installer.bat`.
6. Le setup est généré dans `Installer\Output\PCOptimizer-Setup-v6.exe`.

La publication est volontairement multi-fichiers (`PublishSingleFile=false`) pour éviter les plantages WPF liés aux DLL natives observés sur la v5.1 installée.
