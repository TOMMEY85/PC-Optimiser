# PC Optimizer v4

Application WPF .NET 8 pour Windows 10/11 avec deux profils : Gaming et Productivité.

## Nouveautés v4
- Score séparé **Optimisation Windows** / **Puissance matérielle** pour ne pas confondre réglages et capacité réelle du PC.
- Profil Gaming : plan Hautes performances, suspension sélective USB désactivée, Mode Jeu activé, capture Xbox/Game DVR en arrière-plan désactivée, transparence réduite.
- Nettoyage sécurisé des fichiers temporaires anciens.
- Sauvegarde/restauration du plan d'alimentation, de l'USB et des valeurs registre modifiées.
- Journal des opérations dans `%LOCALAPPDATA%\PCOptimizer\operations.log`.
- Gestion manuelle des applications au démarrage.
- Diagnostic CPU/GPU/RAM/BIOS/stockage/Windows et accès à Windows Update / paramètres graphiques.

## Important
La v4 n'overclocke pas le CPU/GPU, ne modifie pas le BIOS/XMP automatiquement, ne désactive pas Windows Defender, Windows Update, le réseau ou des services Windows critiques. Les gains de FPS ne sont jamais garantis : Fortnite et Call of Duty restent principalement limités par le CPU, le GPU, la RAM, les pilotes et les réglages du jeu.

## Compilation
Dans `PCOptimizer\PCOptimizer.App` :

```powershell
dotnet build
```

Publication EXE autonome Windows x64 :

```powershell
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

EXE généré dans :
`bin\Release\net8.0-windows\win-x64\publish\`
