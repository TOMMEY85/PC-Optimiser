namespace PCOptimizer.Models;

public sealed class StartupApp
{
    public string Name { get; init; } = string.Empty;
    public string Command { get; init; } = string.Empty;
    public string Location { get; init; } = string.Empty;
}
