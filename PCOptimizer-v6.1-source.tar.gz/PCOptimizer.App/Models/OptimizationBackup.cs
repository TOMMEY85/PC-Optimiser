namespace PCOptimizer.Models;

public sealed class OptimizationBackup
{
    public DateTime CreatedAt { get; init; } = DateTime.Now;
    public string ActivePowerSchemeGuid { get; init; } = string.Empty;
    public string ActivePowerSchemeName { get; init; } = string.Empty;
    public int? UsbAcValue { get; init; }
    public int? UsbDcValue { get; init; }
    public List<RegistryValueBackup> RegistryValues { get; init; } = new();
}
