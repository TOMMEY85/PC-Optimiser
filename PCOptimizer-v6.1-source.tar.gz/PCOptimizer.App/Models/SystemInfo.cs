namespace PCOptimizer.Models;

public sealed class SystemInfo
{
    public string Windows { get; init; } = "Windows";
    public string WindowsBuild { get; init; } = "Non détecté";
    public string Cpu { get; init; } = "Non détecté";
    public int CpuCores { get; init; }
    public int CpuThreads { get; init; }
    public int CpuMaxMhz { get; init; }
    public string Gpu { get; init; } = "Non détecté";
    public string GpuDriverVersion { get; init; } = "Non détecté";
    public long GpuMemoryMb { get; init; }
    public double RamGb { get; init; }
    public int RamSpeedMhz { get; init; }
    public string RamManufacturer { get; init; } = "Non détecté";
    public int RamSlotsUsed { get; init; }
    public int RamSlotsTotal { get; init; }
    public string SystemDrive { get; init; } = "Non détecté";
    public string Motherboard { get; init; } = "Non détectée";
    public string Bios { get; init; } = "Non détecté";
    public bool IsLaptop { get; init; }
    public int StartupAppCount { get; init; }
    public string ActivePowerPlan { get; init; } = "Non détecté";
    public bool? UsbSelectiveSuspendEnabled { get; init; }
    public bool? GameModeEnabled { get; init; }
    public bool? TransparencyEnabled { get; init; }
    public int GamingOptimizationScore { get; init; }
    public int ProductivityOptimizationScore { get; init; }
    public int HardwareGamingScore { get; init; }
    public int ProductivityHardwareScore { get; init; }
}
