namespace PCOptimizer.Models;

public sealed class RegistryValueBackup
{
    public string Hive { get; init; } = "HKCU";
    public string Path { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public bool Existed { get; init; }
    public object? Value { get; init; }
    public int Kind { get; init; }
}
