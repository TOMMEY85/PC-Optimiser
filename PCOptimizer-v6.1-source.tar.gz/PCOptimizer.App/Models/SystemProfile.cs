namespace PCOptimizer.Models;

public enum SystemProfile
{
    Gaming,
    Productivity
}
