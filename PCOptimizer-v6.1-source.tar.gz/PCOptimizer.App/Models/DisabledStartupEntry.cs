namespace PCOptimizer.Models;

public sealed class DisabledStartupEntry
{
    public string Name { get; init; } = string.Empty;
    public string Command { get; init; } = string.Empty;
    public string Location { get; init; } = string.Empty;
    public DateTime DisabledAt { get; init; } = DateTime.Now;
}
