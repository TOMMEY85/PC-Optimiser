namespace PCOptimizer.Models;

public sealed class OptimizationResult
{
    public bool Success { get; init; }
    public string Message { get; init; } = string.Empty;

    public static OptimizationResult Ok(string message) => new() { Success = true, Message = message };
    public static OptimizationResult Fail(string message) => new() { Success = false, Message = message };
}
