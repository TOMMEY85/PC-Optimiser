# PC Optimizer v5.1 — création de l'installateur

Cette version transforme PC Optimizer en application Windows installable.

## Résultat attendu

Après compilation, le fichier suivant est créé :

`Installer\Output\PCOptimizer-Setup-v5.1.exe`

Le setup installe PC Optimizer dans **Program Files**, crée une entrée dans le **menu Démarrer**, propose un **raccourci Bureau**, et ajoute PC Optimizer dans **Paramètres > Applications > Applications installées** avec un désinstalleur.

## Prérequis

- SDK .NET installé (ton SDK .NET 10 convient pour compiler le projet net8.0-windows).
- Inno Setup 6 installé sur Windows.

## Méthode la plus simple

1. Double-clique sur `Build-Installer.bat`.
2. Le script publie PC Optimizer en Windows x64 autonome.
3. Il cherche automatiquement Inno Setup 6.
4. Il génère `PCOptimizer-Setup-v5.1.exe` et ouvre le dossier de sortie.

## Si Windows bloque le script PowerShell

Ouvre PowerShell dans le dossier et exécute :

`powershell -NoProfile -ExecutionPolicy Bypass -File .\Build-Installer.ps1`

## Remarque SmartScreen

Le setup et l'application ne sont pas signés numériquement. Windows SmartScreen peut donc afficher un avertissement, surtout sur d'autres PC. Une signature de code Authenticode avec un certificat reconnu est nécessaire pour réduire ces avertissements lors d'une distribution publique.
